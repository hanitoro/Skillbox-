import { createEditableDeliveries } from '../shared/createDeliveries.js';

const deliveryArr = createEditableDeliveries();
const list = document.getElementById('delivery-list');
deliveryArr.forEach(function (delivery) { list.append(delivery.element); });

import test from 'node:test';
import assert from 'node:assert/strict';
import { Delivery } from '../shared/Delivery.js';
import { EditDelivery } from '../shared/EditDelivery.js';
import { createEditableDeliveries } from '../shared/createDeliveries.js';
import { parseDistance, formatDistance } from '../shared/validation.js';

class Element {
  constructor(tag) {
    this.tag = tag;
    this.children = [];
    this.attributes = {};
    this.dataset = {};
    this.handlers = {};
    this.textContent = '';
    this.classList = { add() {} };
  }
  append(...elements) {
    elements.forEach(element => { element.parent = this; this.children.push(element); });
  }
  setAttribute(key, value) { this.attributes[key] = value; }
  addEventListener(type, handler) { this.handlers[type] = handler; }
  dispatchEvent(event) {
    this.handlers[event.type]?.(event);
    if (event.bubbles) this.parent?.dispatchEvent(event);
    return true;
  }
}

function useDocument(t) {
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'document');
  Object.defineProperty(globalThis, 'document', { configurable: true, value: {
    createElement: tag => new Element(tag)
  } });
  t.after(function () {
    if (previous) Object.defineProperty(globalThis, 'document', previous);
    else delete globalThis.document;
  });
}

test('Delivery принимает три аргумента, хранит числовое расстояние и проверяет данные', function () {
  const delivery = new Delivery(' Ольга ', ' ул. Вымыслов, д. 12 ', 8);
  assert.equal(delivery.name, 'Ольга');
  assert.equal(delivery.address, 'ул. Вымыслов, д. 12');
  assert.equal(delivery.distance, 8);
  assert.equal(new Delivery('Имя', 'Адрес', 0).distance, 0);
  assert.equal(new Delivery('Имя', 'Адрес', 1.5).distance, 1.5);
  for (const distance of [-1, NaN, Infinity, '8', null]) {
    assert.throws(() => new Delivery('Имя', 'Адрес', distance), TypeError);
  }
  assert.throws(() => new Delivery(' ', 'Адрес', 1), TypeError);
  assert.throws(() => new Delivery('Имя', '', 1), TypeError);
});

test('Геттер element возвращает ту же карточку, а публичные сеттеры обновляют её DOM', function (t) {
  useDocument(t);
  const delivery = new Delivery('Ольга', 'Адрес', 8);
  const card = delivery.element;
  assert.equal(card.children[2].children[1].textContent, '8 км');
  assert.equal(delivery.element, card);
  const container = new Element('div');
  container.append(card);
  let changed = 0;
  container.addEventListener('deliverychange', () => { changed++; });
  delivery.name = 'Анна';
  delivery.address = 'Новый адрес';
  delivery.distance = 2.5;
  assert.equal(card.children[0].children[1].textContent, 'Анна');
  assert.equal(card.children[1].children[1].textContent, 'Новый адрес');
  assert.equal(card.children[2].children[1].textContent, '2,5 км');
  assert.equal(changed, 3);
  assert.throws(() => { delivery.distance = -1; }, TypeError);
  assert.equal(delivery.distance, 2.5);
});

test('EditDelivery наследует Delivery, добавляет редактирование и меняет вид при всех трёх статусах', function (t) {
  useDocument(t);
  const delivery = new EditDelivery('Дмитрий', 'ул. Задачная, д. 7', 3, 'delivered');
  assert.ok(delivery instanceof Delivery);
  const card = delivery.element;
  assert.equal(card.dataset.status, 'delivered');
  assert.equal(card.children.filter(child => child.tag === 'button').length, 1);
  assert.equal(delivery.element, card);
  assert.equal(card.children.length, 5);
  for (const status of ['delivery', 'canceled', 'delivered']) {
    delivery.status = status;
    assert.equal(delivery.status, status);
    assert.equal(card.dataset.status, status);
  }
  assert.throws(() => { delivery.status = 'unknown'; }, TypeError);
  assert.equal(delivery.status, 'delivered');
  assert.equal(new EditDelivery('Имя', 'Адрес', 1).status, 'delivery');
});

test('Статический метод имеет один аргумент, исключает отменённые доставки и учитывает изменения', function () {
  const deliveries = createEditableDeliveries();
  assert.equal(EditDelivery.getTotalDistance.length, 1);
  assert.equal(EditDelivery.getTotalDistance(deliveries), 11);
  assert.equal(EditDelivery.getTotalDistance([]), 0);
  deliveries[0].distance = 9.5;
  assert.equal(EditDelivery.getTotalDistance(deliveries), 12.5);
  deliveries[2].status = 'delivery';
  assert.equal(EditDelivery.getTotalDistance(deliveries), 23.5);
  deliveries.forEach(delivery => { delivery.status = 'canceled'; });
  assert.equal(EditDelivery.getTotalDistance(deliveries), 0);
  assert.throws(() => EditDelivery.getTotalDistance({}), TypeError);
  assert.throws(() => EditDelivery.getTotalDistance([{ distance: 10 }]), TypeError);
});

test('Поле редактирования принимает дробные расстояния и отклоняет некорректные значения', function () {
  assert.equal(parseDistance(' 1,5 '), 1.5);
  assert.equal(parseDistance('2.75'), 2.75);
  assert.equal(parseDistance('0'), 0);
  for (const value of ['', ' ', '-1', 'abc', 'Infinity', '1,2,3']) {
    assert.throws(() => parseDistance(value), TypeError);
  }
  assert.equal(formatDistance(0.1 + 0.2), '0,3');
});

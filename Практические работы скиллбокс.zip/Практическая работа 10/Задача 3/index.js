import { EditDelivery } from '../shared/EditDelivery.js';
import { createEditableDeliveries } from '../shared/createDeliveries.js';
import { formatDistance } from '../shared/validation.js';

const deliveryArr = createEditableDeliveries();
const list = document.getElementById('delivery-list');
const result = document.getElementById('total-distance');
deliveryArr.forEach(function (delivery) { list.append(delivery.element); });

function showTotalDistance() {
  const totalDistance = EditDelivery.getTotalDistance(deliveryArr);
  result.textContent = 'Общее расстояние: ' + formatDistance(totalDistance) + ' км';
  result.hidden = false;
}

document.getElementById('calculate-total').addEventListener('click', showTotalDistance);
list.addEventListener('deliverychange', function () {
  if (!result.hidden) showTotalDistance();
});

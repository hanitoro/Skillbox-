import { Delivery } from './Delivery.js';
import { validateText, parseDistance, validateStatus, statusLabels } from './validation.js';

let editorCounter = 0;

export class EditDelivery extends Delivery {
  constructor(name, address, distance, status = 'delivery') {
    super(name, address, distance);
    this._status = validateStatus(status);
    this._editButton = null;
    this._statusElement = null;
    this._dialog = null;
  }

  get status() { return this._status; }
  set status(value) {
    this._status = validateStatus(value);
    this._updateStatusView();
    this._notifyChange();
  }

  createElement() {
    const card = super.createElement();
    if (!this._editButton) {
      card.classList.add('editable-card');
      this._editButton = document.createElement('button');
      this._editButton.type = 'button';
      this._editButton.className = 'edit-button';
      this._editButton.textContent = 'Изменить';
      this._editButton.addEventListener('click', () => this.openEditor());
      this._statusElement = document.createElement('span');
      this._statusElement.className = 'visually-hidden';
      card.append(this._editButton, this._statusElement);
    }
    this._updateStatusView();
    return card;
  }

  _updateStatusView() {
    if (!this._element) return;
    this._element.dataset.status = this.status;
    if (this._statusElement) this._statusElement.textContent = 'Статус: ' + statusLabels[this.status];
  }

  createEditor() {
    if (this._dialog) return this._dialog;
    const dialog = document.createElement('dialog');
    const prefix = 'delivery-editor-' + (++editorCounter);
    dialog.className = 'edit-dialog';
    dialog.setAttribute('aria-label', 'Изменить доставку');
    dialog.innerHTML = `
      <button class="close-button" type="button" aria-label="Закрыть">×</button>
      <h2>Изменить</h2>
      <form class="edit-form">
        <label class="visually-hidden" for="${prefix}-name">Имя</label>
        <input id="${prefix}-name" name="name" type="text" placeholder="Имя" required>
        <label class="visually-hidden" for="${prefix}-address">Адрес</label>
        <input id="${prefix}-address" name="address" type="text" placeholder="Адрес" required>
        <label class="visually-hidden" for="${prefix}-distance">Расстояние (км)</label>
        <input id="${prefix}-distance" name="distance" type="text" inputmode="decimal" placeholder="Расстояние (км)" required>
        <label class="visually-hidden" for="${prefix}-status">Статус</label>
        <select id="${prefix}-status" name="status">
          <option value="delivery">Доставляется</option>
          <option value="delivered">Доставлен</option>
          <option value="canceled">Отменён</option>
        </select>
        <p class="form-error" role="alert"></p>
        <button class="primary-button" type="submit">Сохранить</button>
      </form>
    `;
    const form = dialog.querySelector('form');
    const errorMessage = dialog.querySelector('.form-error');
    dialog.querySelector('.close-button').addEventListener('click', () => dialog.close());

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      errorMessage.textContent = '';
      try {
        // Проверяем все поля до изменения экземпляра, чтобы сохранить данные целиком.
        const name = validateText(form.elements.name.value, 'Имя');
        const address = validateText(form.elements.address.value, 'Адрес');
        const distance = parseDistance(form.elements.distance.value);
        const status = validateStatus(form.elements.status.value);
        this.name = name;
        this.address = address;
        this.distance = distance;
        this.status = status;
        dialog.close();
      } catch (error) {
        errorMessage.textContent = error.message;
      }
    });

    this._dialog = dialog;
    document.body.append(dialog);
    return dialog;
  }

  openEditor() {
    const dialog = this.createEditor();
    const form = dialog.querySelector('form');
    form.elements.name.value = this.name;
    form.elements.address.value = this.address;
    form.elements.distance.value = this.distance;
    form.elements.status.value = this.status;
    dialog.querySelector('.form-error').textContent = '';
    dialog.showModal();
    form.elements.name.focus();
  }

  static getTotalDistance(deliveries) {
    if (!Array.isArray(deliveries) || !deliveries.every(delivery => delivery instanceof Delivery)) {
      throw new TypeError('Передайте массив экземпляров доставок.');
    }
    return deliveries.reduce(function (total, delivery) {
      return delivery.status === 'canceled' ? total : total + delivery.distance;
    }, 0);
  }
}

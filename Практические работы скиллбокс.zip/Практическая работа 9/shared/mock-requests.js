const catUrls = [1, 2, 3].map(function (number) {
  return new URL('../images/cat-' + number + '.jpg', import.meta.url).href;
});
const dogUrls = [1, 2, 3].map(function (number) {
  return new URL('../images/dog-' + number + '.jpg', import.meta.url).href;
});

function simulateRequest(urls, onStart) {
  const time = Math.floor(Math.random() * 4) + 2;

  return new Promise(function (resolve) {
    // Передаём рассчитанное время, чтобы запустить соответствующий progress bar.
    onStart(time);
    setTimeout(function () { resolve(urls.slice()); }, time * 1000);
  });
}

export function getCatImages(onStart = function () {}) {
  return simulateRequest(catUrls, onStart);
}

export function getDogImages(onStart = function () {}) {
  return simulateRequest(dogUrls, onStart);
}

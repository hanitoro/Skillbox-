const runningAnimations = new WeakMap();

export function progress(time, progressBarId, timerId) {
  const seconds = Number(time);
  if (!Number.isFinite(seconds) || seconds <= 0) {
    throw new RangeError('Длительность должна быть положительным числом.');
  }

  const bar = document.getElementById(progressBarId);
  const timer = document.getElementById(timerId);
  if (!bar || !timer) throw new Error('Не найдены progress bar или таймер.');

  const previous = runningAnimations.get(bar);
  if (previous) previous.cancel();

  const duration = Math.max(2, seconds);
  const startedAt = performance.now();
  bar.style.transform = 'scaleX(0)';
  bar.setAttribute('aria-valuenow', '0');
  timer.textContent = '0 с';

  return new Promise(function (resolve) {
    let lastSecond = 0;
    const animation = {
      frameId: null,
      cancel: function () {
        cancelAnimationFrame(animation.frameId);
        if (runningAnimations.get(bar) === animation) runningAnimations.delete(bar);
        resolve({ cancelled: true });
      }
    };
    runningAnimations.set(bar, animation);

    function draw(now) {
      if (runningAnimations.get(bar) !== animation) return;
      const elapsed = Math.min(Math.max(0, (now - startedAt) / 1000), duration);
      const fraction = elapsed / duration;
      bar.style.transform = 'scaleX(' + fraction + ')';
      bar.setAttribute('aria-valuenow', String(Math.round(fraction * 100)));

      const wholeSeconds = Math.floor(elapsed);
      if (wholeSeconds !== lastSecond) {
        timer.textContent = wholeSeconds + ' с';
        lastSecond = wholeSeconds;
      }

      if (elapsed >= duration) {
        runningAnimations.delete(bar);
        resolve({ cancelled: false, time: duration });
      } else {
        animation.frameId = requestAnimationFrame(draw);
      }
    }

    animation.frameId = requestAnimationFrame(draw);
  });
}

export function createImageRow(urls, label) {
  const row = document.createElement('div');
  row.className = 'image-row';
  row.setAttribute('role', 'group');
  row.setAttribute('aria-label', label);

  urls.forEach(function (url, index) {
    const image = document.createElement('img');
    image.src = url;
    image.alt = label + ': фотография ' + (index + 1);
    image.width = 160;
    image.height = 110;
    row.append(image);
  });

  return row;
}

export function showError(error) {
  const message = document.getElementById('error-message');
  message.textContent = 'Не удалось завершить загрузку: ' + error.message;
}

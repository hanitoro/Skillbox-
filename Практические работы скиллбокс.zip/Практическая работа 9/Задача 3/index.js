import { getCatImages, getDogImages } from '../shared/mock-requests.js';
import { progress } from '../shared/progress.js';
import { createImageRow, showError } from '../shared/gallery.js';

let catsAnimation;
let dogsAnimation;

getCatImages(function (time) {
  catsAnimation = progress(time, 'cats-progress', 'cats-timer');
}).then(function (urls) {
  // Дожидаемся последнего кадра, чтобы изображения появились после заполнения полосы.
  return catsAnimation.then(function () {
    document.getElementById('cats-gallery').append(createImageRow(urls, 'Коты'));
    document.getElementById('dogs-stage').hidden = false;

    // Второй запрос начинается только после завершения первого и показа котов.
    return getDogImages(function (time) {
      dogsAnimation = progress(time, 'dogs-progress', 'dogs-timer');
    });
  });
}).then(function (urls) {
  return dogsAnimation.then(function () {
    document.getElementById('dogs-gallery').append(createImageRow(urls, 'Собаки'));
  });
}).catch(showError);

import { getCatImages, getDogImages } from '../shared/mock-requests.js';
import { createImageRow, showError } from '../shared/gallery.js';

const gallery = document.getElementById('gallery');
const status = document.getElementById('loading-status');
let completed = 0;

function displayResult(urls, label) {
  // Добавляем ряд после завершения именно этого запроса, сохраняя порядок завершения.
  gallery.append(createImageRow(urls, label));
  completed += 1;
  if (completed === 2) status.textContent = '';
}

getCatImages().then(function (urls) {
  displayResult(urls, 'Коты');
}).catch(function (error) {
  status.textContent = '';
  showError(error);
});

getDogImages().then(function (urls) {
  displayResult(urls, 'Собаки');
}).catch(function (error) {
  status.textContent = '';
  showError(error);
});

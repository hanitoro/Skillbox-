'use strict';

const connectionMonitor = createNetworkMonitor({
  intervalMs: 5000,
  slowMs: 500
});

connectionMonitor.start();
window.addEventListener('pagehide', function () { connectionMonitor.stop(); });
window.addEventListener('pageshow', function (event) {
  if (event.persisted) connectionMonitor.start();
});

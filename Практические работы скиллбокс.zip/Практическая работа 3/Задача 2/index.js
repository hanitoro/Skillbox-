'use strict';

const products = [];
const deliveryForm = document.querySelector('#delivery-form');
const productNameInput = document.querySelector('#product-name');
const weightInput = document.querySelector('#weight');
const distanceInput = document.querySelector('#distance');
const deliveryError = document.querySelector('#delivery-error');
const productList = document.querySelector('#product-list');

function renderProducts() {
  productList.innerHTML = '';

  products.forEach(function (product) {
    const row = document.createElement('tr');
    const values = [
      product.name,
      product.weight,
      product.distance,
      product.deliveryCost.toFixed(2) + ' руб.'
    ];

    values.forEach(function (value) {
      const cell = document.createElement('td');
      cell.textContent = value;
      row.append(cell);
    });

    productList.append(row);
  });
}

deliveryForm.addEventListener('submit', function (event) {
  event.preventDefault();
  deliveryError.textContent = '';

  // Пустые обязательные поля показывают стандартную подсказку браузера.
  if (!deliveryForm.reportValidity()) {
    return;
  }

  const name = productNameInput.value.trim();
  const weight = Number(weightInput.value);
  const distance = Number(distanceInput.value);

  if (name === '') {
    deliveryError.textContent = 'Введите название товара.';
    return;
  }

  if (!Number.isFinite(weight) || weight <= 0 || !Number.isFinite(distance) || distance <= 0) {
    deliveryError.textContent = 'Пожалуйста, введите корректные значения для веса и расстояния.';
    return;
  }

  const deliveryCost = (weight * distance) / 10;

  if (!Number.isFinite(deliveryCost)) {
    deliveryError.textContent = 'Слишком большие значения для расчёта стоимости доставки.';
    return;
  }

  products.push({ name, weight, distance, deliveryCost });
  renderProducts();
  deliveryForm.reset();
});

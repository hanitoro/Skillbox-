'use strict';

const surveyForm = document.querySelector('#survey-form');
const usernameInput = document.querySelector('#username');
const emailInput = document.querySelector('#email');
const ratingInput = document.querySelector('#rating');
const ratingValue = document.querySelector('#rating-value');
const commentsInput = document.querySelector('#comments');
const surveyResults = document.querySelector('#survey-results');

function validateUsername() {
  const onlySpaces = usernameInput.value !== '' && usernameInput.value.trim() === '';
  usernameInput.setCustomValidity(onlySpaces ? 'Введите имя пользователя.' : '');
}

function validateEmail() {
  // Сначала снимаем старую ошибку, затем проверяем текущий формат email.
  emailInput.setCustomValidity('');

  if (emailInput.validity.typeMismatch) {
    emailInput.setCustomValidity('Введите адрес e-mail.');
  }
}

usernameInput.addEventListener('input', validateUsername);
emailInput.addEventListener('input', validateEmail);

ratingInput.addEventListener('input', function () {
  ratingValue.value = ratingInput.value;
});

surveyForm.addEventListener('submit', function (event) {
  event.preventDefault();
  validateUsername();
  validateEmail();

  if (!surveyForm.reportValidity()) {
    return;
  }

  const selectedGender = surveyForm.querySelector('input[name="gender"]:checked');
  const selectedInterests = surveyForm.querySelectorAll('input[name="interests"]:checked');
  const interests = Array.from(selectedInterests, function (input) {
    return input.value;
  });

  const heading = document.createElement('h2');
  heading.textContent = 'Результаты опроса:';
  surveyResults.replaceChildren(heading);

  const results = [
    ['Имя пользователя', usernameInput.value.trim()],
    ['Email', emailInput.value.trim()],
    ['Пол', selectedGender ? selectedGender.value : 'Не указан'],
    ['Оценка сервиса', ratingInput.value],
    ['Интересы пользователя', interests.length > 0 ? interests.join(', ') : 'Не выбраны'],
    ['Дополнительные комментарии', commentsInput.value.trim()]
  ];

  results.forEach(function (result) {
    const paragraph = document.createElement('p');
    paragraph.textContent = result[0] + ': ' + result[1];
    surveyResults.append(paragraph);
  });

  surveyResults.hidden = false;
});

'use strict';

const cardTextInput = document.querySelector('#card-text');
const cardColorSelect = document.querySelector('#card-color');
const card = document.querySelector('#card');

cardTextInput.addEventListener('input', function () {
  card.textContent = cardTextInput.value;
});

cardTextInput.addEventListener('focus', function () {
  cardTextInput.classList.add('focused');
});

cardTextInput.addEventListener('blur', function () {
  cardTextInput.classList.remove('focused');
});

cardColorSelect.addEventListener('change', function () {
  card.style.backgroundColor = cardColorSelect.value;
});

card.style.backgroundColor = cardColorSelect.value;

'use strict';

const giftArr = [
  {
    title: 'Скидка 20% на первую покупку в нашем магазине!',
    icon: 'img/discount.svg'
  },
  {
    title: 'Скидка 10% на всё!',
    icon: 'img/discount_2.svg'
  },
  {
    title: 'Подарок при первой покупке в нашем магазине!',
    icon: 'img/gift.svg'
  },
  {
    title: 'Бесплатная доставка для вас!',
    icon: 'img/delivery.svg'
  },
  {
    title: 'Сегодня день больших скидок!',
    icon: 'img/discount_3.svg'
  }
];

function showGift() {
  const randomIndex = Math.floor(Math.random() * giftArr.length);
  const gift = giftArr[randomIndex];

  const overlay = document.createElement('div');
  overlay.className = 'overlay';

  const card = document.createElement('div');
  card.className = 'gift-card';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-modal', 'true');
  card.setAttribute('aria-labelledby', 'gift-title');

  const icon = document.createElement('img');
  icon.className = 'gift-icon';
  icon.src = gift.icon;
  icon.alt = '';
  icon.width = 144;
  icon.height = 144;

  const content = document.createElement('div');
  content.className = 'gift-content';

  const title = document.createElement('h1');
  title.id = 'gift-title';
  title.textContent = gift.title;

  const closeButton = document.createElement('button');
  closeButton.type = 'button';
  closeButton.textContent = 'Отлично!';
  closeButton.addEventListener('click', function () {
    overlay.remove();
  });

  overlay.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      overlay.remove();
    }

    if (event.key === 'Tab') {
      event.preventDefault();
      closeButton.focus();
    }
  });

  content.append(title, closeButton);
  card.append(icon, content);
  overlay.append(card);
  document.body.append(overlay);
  closeButton.focus();
}

setTimeout(showGift, 3000);

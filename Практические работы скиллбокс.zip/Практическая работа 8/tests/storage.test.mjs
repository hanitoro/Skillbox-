import test from 'node:test';
import assert from 'node:assert/strict';
import { getValidationErrors, isValidDate } from '../js/utils/validation.js';
import { sortItems, searchItems, formatDate } from '../js/utils/items.js';
import * as storage from '../js/storage.js';

test('Валидация обязательных полей, веса и календарных дат', function () {
  assert.equal(isValidDate('2028-02-29'), true);
  for (const date of ['2027-02-29', '2028-04-31', '2028-13-01', '0000-01-01', '', '31.12.2028']) {
    assert.equal(isValidDate(date), false);
  }
  for (const weight of ['', '  ', '0', '-1', 'Infinity', 'abc']) {
    assert.ok(getValidationErrors({ title: 'Посуда', shelf: '1', weight, expiresAt: '2028-01-01' }).weight);
  }
  const errors = getValidationErrors({ title: ' ', shelf: ' ', weight: '2', expiresAt: '' });
  assert.ok(errors.title);
  assert.ok(errors.shelf);
  assert.ok(errors.expiresAt);
});

test('Хранение, перезагрузка, четыре сортировки, поиск, редактирование и удаление', async function (t) {
  const data = new Map();
  let blockRead = false;
  let blockWrite = false;
  const previousStorage = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
    getItem(key) {
      if (blockRead) throw new Error('Denied');
      return data.has(key) ? data.get(key) : null;
    },
    setItem(key, value) {
      if (blockWrite) throw new Error('Quota exceeded');
      data.set(key, value);
    }
  } });
  t.after(function () {
    if (previousStorage) Object.defineProperty(globalThis, 'localStorage', previousStorage);
    else delete globalThis.localStorage;
  });

  assert.deepEqual(storage.getItems(), []);
  const first = storage.addItem({ title: '  Посуда  ', shelf: '10', weight: '10', expiresAt: '2028-01-01' });
  const second = storage.addItem({ title: 'Архив', shelf: '2', weight: 2, expiresAt: '2027-12-31' });
  assert.notEqual(first.id, second.id);
  assert.equal(first.title, 'Посуда');
  assert.equal(first.weight, 10);
  assert.equal(JSON.parse(data.get('theme8_warehouse'))[0].weight, 10);
  const reloaded = await import('../js/storage.js?reload=1');
  assert.equal(reloaded.getItems().length, 2);

  assert.deepEqual(sortItems(storage.getItems(), 'title').map(item => item.title), ['Архив', 'Посуда']);
  assert.deepEqual(sortItems(storage.getItems(), 'shelf').map(item => item.shelf), ['2', '10']);
  assert.deepEqual(sortItems(storage.getItems(), 'weight').map(item => item.weight), [2, 10]);
  assert.deepEqual(sortItems(storage.getItems(), 'expiresAt').map(item => item.expiresAt), ['2027-12-31', '2028-01-01']);
  assert.equal(storage.getItems()[0].id, first.id);
  assert.equal(searchItems(storage.getItems(), '  ПОСУДА ')[0].id, first.id);
  assert.equal(searchItems(storage.getItems(), '2')[0].id, second.id);
  assert.equal(formatDate('2028-02-29'), '29.02.2028');

  storage.updateItem(first.id, { title: 'Тарелки', shelf: '3', weight: 1.5, expiresAt: '2028-02-29' });
  assert.equal(storage.getItem(first.id).weight, 1.5);
  assert.equal(storage.getItems().length, 2);
  assert.throws(() => storage.updateItem('missing', { title: 'Тест', shelf: '1', weight: 1, expiresAt: '2028-01-01' }), /не найдена/);

  const beforeFailure = data.get('theme8_warehouse');
  blockWrite = true;
  assert.throws(() => storage.removeItem(first.id), /сохранить/);
  assert.equal(data.get('theme8_warehouse'), beforeFailure);
  blockWrite = false;
  storage.removeItem(second.id);
  assert.equal(storage.getItem(second.id), null);
  assert.equal(storage.getItems()[0].title, 'Тарелки');
  storage.removeItem(first.id);
  assert.deepEqual(reloaded.getItems(), []);
  assert.equal(data.get('theme8_warehouse'), '[]');

  for (const raw of ['{broken', '{}', '[null]', JSON.stringify([{ ...first, weight: -1 }]), JSON.stringify([first, first])]) {
    data.set('theme8_warehouse', raw);
    assert.throws(() => storage.getItems(), /данные склада/);
  }
  blockRead = true;
  assert.throws(() => storage.getItems(), /localStorage/);
});

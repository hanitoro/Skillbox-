import { getValidationErrors, normalizeItem } from '../utils/validation.js';

export function createItemForm({ initialItem = null, submitText = 'Добавить запись', onSubmit }) {
  const form = document.createElement('form');
  form.className = 'item-form';
  form.innerHTML = `
    <label class="visually-hidden" for="item-title">Название</label>
    <input id="item-title" name="title" type="text" placeholder="Название" required>
    <label class="visually-hidden" for="item-shelf">Полка</label>
    <input id="item-shelf" name="shelf" type="text" placeholder="Полка" required>
    <label class="visually-hidden" for="item-weight">Вес (кг)</label>
    <input id="item-weight" name="weight" type="number" min="0" step="any" placeholder="Вес (кг)" required>
    <label class="visually-hidden" for="item-date">Время хранения</label>
    <input id="item-date" name="expiresAt" type="date" min="0001-01-01" max="9999-12-31" required>
    <p class="error form-error" role="alert"></p>
    <button class="primary-button" type="submit"></button>
  `;

  const fields = {};
  const names = ['title', 'shelf', 'weight', 'expiresAt'];
  const errorMessage = form.querySelector('.form-error');
  form.querySelector('button').textContent = submitText;

  function getValues() {
    return Object.fromEntries(names.map(function (name) { return [name, fields[name].value]; }));
  }

  function validateField(name) {
    const field = fields[name];
    const errors = getValidationErrors(getValues());
    // Для пустых полей сохраняем стандартную подсказку required.
    field.setCustomValidity(field.value === '' ? '' : errors[name] || '');
  }

  names.forEach(function (name) {
    const field = form.querySelector('[name="' + name + '"]');
    fields[name] = field;
    field.value = initialItem ? initialItem[name] : '';
    field.addEventListener('input', function () {
      validateField(name);
      errorMessage.textContent = '';
    });
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    names.forEach(validateField);
    if (!form.reportValidity()) return;

    try {
      onSubmit(normalizeItem(getValues()));
    } catch (error) {
      errorMessage.textContent = error.message;
    }
  });

  return form;
}

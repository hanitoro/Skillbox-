export function showPreloader() {
  document.getElementById('preloader').hidden = false;
}

export function hidePreloader() {
  document.getElementById('preloader').hidden = true;
}

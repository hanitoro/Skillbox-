import { formatDate } from '../utils/items.js';

const columns = [
  ['title', 'Название'],
  ['shelf', 'Полка'],
  ['weight', 'Вес (кг)'],
  ['expiresAt', 'Время хранения']
];

export function createTable({ items, sortKey, onSort, onDelete, emptyMessage }) {
  const wrapper = document.createElement('div');
  wrapper.className = 'table-wrapper';
  const table = document.createElement('table');
  const head = document.createElement('thead');
  const headingRow = document.createElement('tr');

  columns.forEach(function ([key, title]) {
    const heading = document.createElement('th');
    heading.scope = 'col';
    heading.setAttribute('aria-sort', key === sortKey ? 'ascending' : 'none');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'sort-button';
    button.textContent = title;
    button.title = 'Сортировать по возрастанию';
    button.addEventListener('click', function () { onSort(key); });
    heading.append(button);
    headingRow.append(heading);
  });

  const actionsHeading = document.createElement('th');
  actionsHeading.scope = 'col';
  actionsHeading.textContent = 'Действия';
  headingRow.append(actionsHeading);
  head.append(headingRow);

  const body = document.createElement('tbody');
  items.forEach(function (item) {
    const row = document.createElement('tr');
    [item.title, item.shelf, item.weight, formatDate(item.expiresAt)].forEach(function (value) {
      const cell = document.createElement('td');
      cell.textContent = value;
      row.append(cell);
    });

    const actions = document.createElement('td');
    const controls = document.createElement('div');
    controls.className = 'row-actions';
    const edit = document.createElement('a');
    edit.href = '#/edit/' + encodeURIComponent(item.id);
    edit.textContent = 'Изменить';
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'delete-button';
    remove.textContent = 'Удалить';
    remove.setAttribute('aria-label', 'Удалить запись «' + item.title + '»');
    remove.addEventListener('click', function () { onDelete(item.id); });
    controls.append(edit, remove);
    actions.append(controls);
    row.append(actions);
    body.append(row);
  });

  if (!items.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 5;
    cell.className = 'empty-state';
    cell.textContent = emptyMessage;
    row.append(cell);
    body.append(row);
  }

  table.append(head, body);
  wrapper.append(table);
  return wrapper;
}

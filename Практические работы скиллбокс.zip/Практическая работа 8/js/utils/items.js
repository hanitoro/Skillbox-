export function formatDate(value) {
  const [year, month, day] = value.split('-');
  return day + '.' + month + '.' + year;
}

export function sortItems(items, key) {
  const result = items.slice();
  if (!key) return result;

  return result.sort(function (first, second) {
    if (key === 'weight') return first.weight - second.weight;
    if (key === 'expiresAt') return first.expiresAt.localeCompare(second.expiresAt);
    return first[key].localeCompare(second[key], 'ru', { numeric: true, sensitivity: 'base' });
  });
}

export function searchItems(items, query) {
  const search = query.trim().toLocaleLowerCase('ru');
  return items.filter(function (item) {
    return item.title.toLocaleLowerCase('ru').includes(search)
      || item.shelf.toLocaleLowerCase('ru').includes(search);
  });
}

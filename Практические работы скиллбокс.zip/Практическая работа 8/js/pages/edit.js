import { getItem, updateItem } from '../storage.js';
import { createItemForm } from '../components/item-form.js';

export function renderPage({ navigate, id }) {
  const item = getItem(id);
  const section = document.createElement('section');
  section.className = 'form-page';
  const heading = document.createElement('h1');
  heading.textContent = item ? 'Редактировать запись' : 'Запись не найдена';
  section.append(heading);

  if (item) {
    section.append(createItemForm({
      initialItem: item,
      submitText: 'Сохранить изменения',
      onSubmit: function (data) {
        updateItem(id, data);
        navigate('/');
      }
    }));
  }

  const back = document.createElement('a');
  back.className = 'back-link';
  back.href = '#/';
  back.textContent = 'Вернуться на склад';
  section.append(back);
  return section;
}

import { addItem } from '../storage.js';
import { createItemForm } from '../components/item-form.js';

export function renderPage({ navigate }) {
  const section = document.createElement('section');
  section.className = 'form-page';
  const heading = document.createElement('h1');
  heading.textContent = 'Добавить запись';
  const form = createItemForm({
    onSubmit: function (data) {
      addItem(data);
      navigate('/');
    }
  });
  const back = document.createElement('a');
  back.className = 'back-link';
  back.href = '#/';
  back.textContent = 'Вернуться на склад';
  section.append(heading, form, back);
  return section;
}

import { getItems, removeItem } from '../storage.js';
import { createTable } from '../components/table.js';
import { searchItems, sortItems } from '../utils/items.js';

export function renderPage() {
  let items = getItems();
  let sortKey = null;
  const section = document.createElement('section');
  section.className = 'warehouse-page';
  section.innerHTML = `
    <h1>Склад</h1>
    <div class="warehouse-toolbar">
      <label class="visually-hidden" for="search">Поиск по названию или полке</label>
      <input id="search" type="search" placeholder="Поиск по названию или полке">
      <a class="primary-button" href="#/add">Добавить запись</a>
    </div>
    <p class="error page-error" role="alert"></p>
    <div class="table-container"></div>
  `;
  const search = section.querySelector('#search');
  const errorMessage = section.querySelector('.page-error');
  const tableContainer = section.querySelector('.table-container');

  function renderTable() {
    const filtered = sortItems(searchItems(items, search.value), sortKey);
    tableContainer.replaceChildren(createTable({
      items: filtered,
      sortKey,
      emptyMessage: search.value.trim() ? 'Ничего не найдено.' : 'На складе пока нет записей.',
      onSort: function (key) {
        sortKey = key;
        renderTable();
      },
      onDelete: function (id) {
        try {
          removeItem(id);
          items = getItems();
          errorMessage.textContent = '';
          renderTable();
        } catch (error) {
          errorMessage.textContent = error.message;
        }
      }
    }));
  }

  search.addEventListener('input', renderTable);
  renderTable();
  return section;
}

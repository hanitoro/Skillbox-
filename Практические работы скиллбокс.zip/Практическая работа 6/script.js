'use strict';

const API_URL = 'https://sb-film.skillbox.cc/films';
// Идентификатор списка из исходного приложения Homework.zip.
const API_EMAIL = 'ovikdevil@gmail.com';

const filmForm = document.getElementById('film-form');
const titleInput = document.getElementById('title');
const genreInput = document.getElementById('genre');
const yearInput = document.getElementById('releaseYear');
const watchedInput = document.getElementById('isWatched');
const addButton = document.getElementById('add-film');
const deleteAllButton = document.getElementById('delete-all');
const filterTitle = document.getElementById('filter-title');
const filterGenre = document.getElementById('filter-genre');
const filterYear = document.getElementById('filter-year');
const filterWatched = document.getElementById('filter-watched');
const filmTableBody = document.getElementById('film-tbody');
const formError = document.getElementById('form-error');
const requestError = document.getElementById('request-error');
const tableStatus = document.getElementById('table-status');

let filterTimer;
let loadController = null;
let loadVersion = 0;
let mutationPending = false;

async function apiRequest(path = '', options = {}) {
  const controller = new AbortController();
  const externalSignal = options.signal;
  const cancelRequest = function () { controller.abort(); };
  let timedOut = false;

  if (externalSignal) {
    if (externalSignal.aborted) controller.abort();
    else externalSignal.addEventListener('abort', cancelRequest, { once: true });
  }

  const timeout = setTimeout(function () {
    timedOut = true;
    controller.abort();
  }, 15000);

  try {
    const response = await fetch(API_URL + path, {
      ...options,
      signal: controller.signal,
      headers: { email: API_EMAIL, ...options.headers }
    });
    if (!response.ok) {
      throw new Error('Сервер вернул ошибку ' + response.status + '. Повторите действие.');
    }
    // DELETE может вернуть пустой ответ; список нужен только для GET.
    return !options.method || options.method === 'GET' ? await response.json() : null;
  } catch (error) {
    if (timedOut) throw new Error('Сервер не ответил за 15 секунд. Повторите действие позже.');
    throw error;
  } finally {
    clearTimeout(timeout);
    if (externalSignal) externalSignal.removeEventListener('abort', cancelRequest);
  }
}

function showRequestError(error) {
  requestError.textContent = error instanceof TypeError
    ? 'Не удалось связаться с сервером. Проверьте подключение к интернету.'
    : error.message;
}

function getFilterQuery() {
  const parameters = new URLSearchParams();
  if (filterTitle.value.trim()) parameters.set('title', filterTitle.value.trim());
  if (filterGenre.value.trim()) parameters.set('genre', filterGenre.value.trim());
  if (filterYear.value.trim()) parameters.set('releaseYear', filterYear.value.trim());
  if (filterWatched.value !== '') parameters.set('isWatched', filterWatched.value);
  const query = parameters.toString();
  return query ? '?' + query : '';
}

function displayFilms(films) {
  filmTableBody.replaceChildren();
  films.forEach(function (film) {
    const row = document.createElement('tr');
    [film.title, film.genre, film.releaseYear, film.isWatched ? 'Да' : 'Нет'].forEach(function (value) {
      const cell = document.createElement('td');
      cell.textContent = value;
      row.append(cell);
    });
    const actionCell = document.createElement('td');
    const deleteButton = document.createElement('button');
    deleteButton.type = 'button';
    deleteButton.className = 'delete-button';
    deleteButton.textContent = 'Удалить';
    deleteButton.disabled = mutationPending;
    deleteButton.setAttribute('aria-label', 'Удалить фильм «' + film.title + '»');
    deleteButton.addEventListener('click', function () { return deleteFilm(film.id); });
    actionCell.append(deleteButton);
    row.append(actionCell);
    filmTableBody.append(row);
  });
}

async function renderTable() {
  const version = ++loadVersion;
  if (loadController) loadController.abort();
  const controller = new AbortController();
  loadController = controller;
  tableStatus.textContent = 'Загрузка…';
  requestError.textContent = '';

  try {
    const films = await apiRequest(getFilterQuery(), { signal: controller.signal });
    if (version !== loadVersion) return;
    if (!Array.isArray(films)) throw new Error('Сервер вернул некорректный список фильмов.');
    displayFilms(films);
    tableStatus.textContent = films.length ? '' : 'Фильмы не найдены.';
  } catch (error) {
    if (version !== loadVersion) return;
    filmTableBody.replaceChildren();
    tableStatus.textContent = '';
    showRequestError(error);
  } finally {
    if (version === loadVersion) loadController = null;
  }
}

function setMutationBusy(busy) {
  [addButton, deleteAllButton, titleInput, genreInput, yearInput, watchedInput].forEach(function (element) {
    element.disabled = busy;
  });
  filmTableBody.querySelectorAll('button').forEach(function (button) { button.disabled = busy; });
}

async function mutateFilms(action) {
  if (mutationPending) return false;
  mutationPending = true;
  setMutationBusy(true);
  requestError.textContent = '';
  try {
    await action();
    await renderTable();
    return true;
  } catch (error) {
    showRequestError(error);
    return false;
  } finally {
    mutationPending = false;
    setMutationBusy(false);
  }
}

async function addFilm(film) {
  return mutateFilms(function () {
    return apiRequest('', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(film)
    });
  });
}

async function deleteFilm(id) {
  return mutateFilms(function () {
    return apiRequest('/' + encodeURIComponent(id), { method: 'DELETE' });
  });
}

async function deleteAllFilms() {
  return mutateFilms(function () { return apiRequest('', { method: 'DELETE' }); });
}

async function handleFormSubmit(event) {
  event.preventDefault();
  formError.textContent = '';
  const title = titleInput.value.trim();
  const genre = genreInput.value.trim();
  const releaseYear = Number(yearInput.value);

  if (!title || !genre || !yearInput.value.trim()) {
    formError.textContent = 'Заполните название, жанр и год выпуска фильма.';
    return;
  }
  if (!Number.isInteger(releaseYear) || releaseYear < 1 || releaseYear > 9999) {
    formError.textContent = 'Введите корректный год выпуска: целое число от 1 до 9999.';
    return;
  }
  const added = await addFilm({ title, genre, releaseYear: String(releaseYear), isWatched: watchedInput.checked });
  if (added) filmForm.reset();
}

function scheduleFilter() {
  clearTimeout(filterTimer);
  filterTimer = setTimeout(renderTable, 250);
}

filmForm.addEventListener('submit', handleFormSubmit);
deleteAllButton.addEventListener('click', deleteAllFilms);
[filterTitle, filterGenre, filterYear].forEach(function (input) {
  input.addEventListener('input', scheduleFilter);
});
filterWatched.addEventListener('change', function () {
  clearTimeout(filterTimer);
  return renderTable();
});

renderTable();

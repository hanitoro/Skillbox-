'use strict';

const books = [
  'Мастер и Маргарита',
  'Гарри Поттер',
  'Над пропастью во ржи',
  'Властелин колец',
  'Дюна',
  'Отцы и дети'
];

const bookList = document.querySelector('#book-list');
const addBookButton = document.querySelector('#add-book');
const searchBookButton = document.querySelector('#search-book');

function renderBooks(searchTitle = '') {
  bookList.innerHTML = '';

  books.forEach(function (book) {
    const item = document.createElement('li');
    item.textContent = book;

    if (book.toLocaleLowerCase('ru') === searchTitle) {
      item.classList.add('found');
    }

    bookList.append(item);
  });
}

addBookButton.addEventListener('click', function () {
  const input = prompt('Введите название книги:');

  if (input === null || input.trim() === '') {
    alert('Название книги не введено!');
    return;
  }

  books.push(input.trim());
  renderBooks();
});

searchBookButton.addEventListener('click', function () {
  const input = prompt('Введите название книги для поиска:');

  if (input === null) {
    return;
  }

  const searchTitle = input.trim().toLocaleLowerCase('ru');
  const foundBook = books.find(function (book) {
    return book.toLocaleLowerCase('ru') === searchTitle;
  });

  renderBooks(searchTitle);

  if (foundBook === undefined) {
    alert('Книга не найдена!');
  }
});

renderBooks();

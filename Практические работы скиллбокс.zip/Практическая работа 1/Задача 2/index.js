'use strict';

const heights = [164, 157, 160, 143, 170];
let minimumHeight = null;

const heightList = document.querySelector('#height-list');
const addHeightButton = document.querySelector('#add-height');
const filterHeightsButton = document.querySelector('#filter-heights');

function renderHeights() {
  heightList.innerHTML = '';

  const visibleHeights = minimumHeight === null
    ? heights
    : heights.filter(function (height) {
      return height >= minimumHeight;
    });

  visibleHeights.forEach(function (height) {
    const item = document.createElement('li');
    item.textContent = height;
    heightList.append(item);
  });
}

addHeightButton.addEventListener('click', function () {
  const input = prompt('Введите рост ученика в сантиметрах:');

  if (input === null || input.trim() === '') {
    alert('Рост не введён!');
    return;
  }

  const height = Number(input.trim().replace(',', '.'));

  if (!Number.isFinite(height) || height <= 0) {
    alert('Введите положительное число!');
    return;
  }

  heights.push(height);
  renderHeights();
});

filterHeightsButton.addEventListener('click', function () {
  const input = prompt('Введите минимальный рост в сантиметрах:');

  if (input === null || input.trim() === '') {
    minimumHeight = null;
    renderHeights();
    return;
  }

  const height = Number(input.trim().replace(',', '.'));

  if (!Number.isFinite(height) || height <= 0) {
    alert('Введите положительное число!');
    return;
  }

  minimumHeight = height;
  renderHeights();
});

renderHeights();

'use strict';

const products = ['Яблоки', 'Кофе', 'Арбуз', 'Сахар', 'Книга', 'Молоко', 'Макароны'];

const productList = document.querySelector('#product-list');
const addProductButton = document.querySelector('#add-product');

function renderProducts() {
  products.sort(function (firstProduct, secondProduct) {
    return firstProduct.localeCompare(secondProduct, 'ru', { sensitivity: 'base' });
  });

  productList.innerHTML = '';

  products.forEach(function (product) {
    const item = document.createElement('li');
    item.textContent = product;
    productList.append(item);
  });
}

addProductButton.addEventListener('click', function () {
  const input = prompt('Введите название товара:');

  if (input === null || input.trim() === '') {
    alert('Название товара не введено!');
    return;
  }

  products.push(input.trim());
  renderProducts();
});

renderProducts();

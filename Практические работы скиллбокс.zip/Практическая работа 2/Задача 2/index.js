'use strict';

const itemList = document.querySelector('#item-list');
const addItemButton = document.querySelector('#add-item');
const removeItemButton = document.querySelector('#remove-item');

addItemButton.addEventListener('click', function () {
  const item = document.createElement('li');
  item.textContent = 'Новый элемент списка';
  itemList.append(item);
});

removeItemButton.addEventListener('click', function () {
  const lastItem = itemList.lastElementChild;

  if (lastItem) {
    lastItem.remove();
  }
});

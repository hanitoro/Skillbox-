"""Локальный HTTP-сервер для приложения с JavaScript-модулями."""

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser


def main():
    directory = Path(__file__).resolve().parent
    handler = partial(SimpleHTTPRequestHandler, directory=str(directory))
    # Постоянный адрес сохраняет доступ к тому же localStorage после перезапуска.
    try:
        server = ThreadingHTTPServer(("127.0.0.1", 8008), handler)
    except OSError:
        print("Не удалось открыть порт 8008. Если склад уже запущен, откройте http://127.0.0.1:8008/.", flush=True)
        print("Иначе освободите порт и повторите запуск.", flush=True)
        raise SystemExit(1)

    with server:
        url = "http://127.0.0.1:8008/"
        print(f"Тема 8: {url}", flush=True)
        print("Оставьте это окно открытым. Для остановки нажмите Ctrl+C.", flush=True)
        webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()

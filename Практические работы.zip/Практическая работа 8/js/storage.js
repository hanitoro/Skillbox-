import { getValidationErrors, isValidDate, normalizeItem } from './utils/validation.js';

const STORAGE_KEY = 'theme8_warehouse';

export function getItems() {
  let raw;
  try {
    raw = localStorage.getItem(STORAGE_KEY);
  } catch {
    throw new Error('Нет доступа к localStorage. Разрешите хранение данных в браузере.');
  }
  if (raw === null) return [];

  let items;
  try {
    items = JSON.parse(raw);
  } catch {
    throw new Error('Сохранённые данные склада повреждены.');
  }

  const valid = Array.isArray(items) && items.every((item) => {
    return item !== null && typeof item === 'object'
      && typeof item.id === 'string' && item.id !== ''
      && typeof item.title === 'string' && item.title.trim() !== ''
      && typeof item.shelf === 'string' && item.shelf.trim() !== ''
      && typeof item.weight === 'number' && Number.isFinite(item.weight) && item.weight > 0
      && isValidDate(item.expiresAt);
  });

  if (!valid || new Set(items.map(item => item.id)).size !== items.length) {
    throw new Error('Сохранённые данные склада имеют неверный формат.');
  }
  return items;
}

function saveItems(items) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    throw new Error('Не удалось сохранить изменения. Проверьте доступ к хранилищу и свободное место.');
  }
}

function validateData(data) {
  const errors = getValidationErrors(data);
  if (Object.keys(errors).length) throw new Error(Object.values(errors)[0]);
}

export function getItem(id) {
  return getItems().find(item => item.id === id) || null;
}

export function addItem(data) {
  validateData(data);
  const items = getItems();
  let id;
  do {
    id = globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2);
  } while (items.some(item => item.id === id));

  const item = { ...normalizeItem(data), id };
  saveItems(items.concat(item));
  return item;
}

export function updateItem(id, data) {
  validateData(data);
  const items = getItems();
  if (!items.some(item => item.id === id)) throw new Error('Запись не найдена.');
  saveItems(items.map(item => item.id === id ? { ...normalizeItem(data), id } : item));
}

export function removeItem(id) {
  const items = getItems();
  saveItems(items.filter(item => item.id !== id));
}

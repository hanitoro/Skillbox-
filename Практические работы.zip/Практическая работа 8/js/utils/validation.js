export function isValidDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value.startsWith('0000')) {
    return false;
  }
  const date = new Date(value + 'T00:00:00Z');
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export function getValidationErrors(values) {
  const errors = {};
  if (!String(values.title ?? '').trim()) errors.title = 'Введите название.';
  if (!String(values.shelf ?? '').trim()) errors.shelf = 'Укажите полку.';

  const weight = +values.weight;
  if (!String(values.weight ?? '').trim() || !Number.isFinite(weight) || weight <= 0) {
    errors.weight = 'Введите вес больше нуля.';
  }

  if (!isValidDate(values.expiresAt)) errors.expiresAt = 'Укажите корректную дату хранения.';
  return errors;
}

export function normalizeItem(values) {
  return {
    title: values.title.trim(),
    shelf: values.shelf.trim(),
    weight: +values.weight,
    expiresAt: values.expiresAt
  };
}

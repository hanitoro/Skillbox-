export function showPreloader() {
  document.querySelector('.preloader').hidden = false;
}

export function hidePreloader() {
  document.querySelector('.preloader').hidden = true;
}

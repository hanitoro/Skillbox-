import { getValidationErrors, normalizeItem } from '../utils/validation.js';

export function createItemForm({ initialItem = null, submitText = 'Добавить запись', onSubmit }) {
  const form = document.createElement('form');
  form.className = 'item-form';
  form.innerHTML = `
    <input class="item-title" name="title" type="text" placeholder="Название" required aria-label="Название">
    <input class="item-shelf" name="shelf" type="text" placeholder="Полка" required aria-label="Полка">
    <input class="item-weight" name="weight" type="number" min="0" step="any" placeholder="Вес (кг)" required aria-label="Вес (кг)">
    <input class="item-date" name="expiresAt" type="date" min="0001-01-01" max="9999-12-31" required aria-label="Время хранения">
    <p class="error form-error" role="alert"></p>
    <button class="primary-button" type="submit"></button>
  `;

  const fields = {};
  const names = ['title', 'shelf', 'weight', 'expiresAt'];
  const errorMessage = form.querySelector('.form-error');
  form.querySelector('button').textContent = submitText;

  function getValues() {
    return Object.fromEntries(names.map(name => [name, fields[name].value]));
  }

  function validateField(name) {
    const field = fields[name];
    const errors = getValidationErrors(getValues());
    // Для пустых полей сохраняем стандартную подсказку required.
    field.setCustomValidity(field.value === '' ? '' : errors[name] || '');
  }

  names.forEach((name) => {
    const field = form.querySelector('[name="' + name + '"]');
    fields[name] = field;
    field.value = initialItem ? initialItem[name] : '';
    field.addEventListener('input', () => {
      validateField(name);
      errorMessage.textContent = '';
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    names.forEach(validateField);
    if (!form.reportValidity()) return;

    try {
      onSubmit(normalizeItem(getValues()));
    } catch (error) {
      errorMessage.textContent = error.message;
    }
  });

  return form;
}

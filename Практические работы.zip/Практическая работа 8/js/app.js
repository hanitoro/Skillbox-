import { showPreloader, hidePreloader } from './components/preloader.js';

const app = document.querySelector('.app');
let navigationVersion = 0;

export function navigate(path) {
  const hash = '#' + path;
  if (location.hash === hash) loadPage();
  else location.hash = hash;
}

async function loadPage() {
  const version = ++navigationVersion;
  app.setAttribute('aria-busy', 'true');
  showPreloader();

  try {
    // Даём браузеру отобразить прелоадер до загрузки модуля страницы.
    await new Promise((resolve) => {
      requestAnimationFrame(() => { requestAnimationFrame(resolve); });
    });

    const path = location.hash.slice(1) || '/';
    let page;
    let id = null;

    if (path === '/') {
      page = await import('./pages/warehouse.js');
    } else if (path === '/add') {
      page = await import('./pages/add.js');
    } else if (path.startsWith('/edit/')) {
      id = decodeURIComponent(path.slice('/edit/'.length));
      page = await import('./pages/edit.js');
    } else {
      throw new Error('Страница не найдена.');
    }

    if (version !== navigationVersion) return;
    const view = page.renderPage({ navigate, id });
    app.replaceChildren(view);
    const heading = view.querySelector('h1');
    document.title = heading ? heading.textContent : 'Склад';
    window.scrollTo(0, 0);

    if (heading) {
      heading.tabIndex = -1;
      heading.focus({ preventScroll: true });
    }
  } catch (error) {
    if (version !== navigationVersion) return;
    const section = document.createElement('section');
    const heading = document.createElement('h1');
    heading.textContent = 'Не удалось открыть страницу';
    const message = document.createElement('p');
    message.className = 'error';
    message.setAttribute('role', 'alert');
    message.textContent = error.message;
    const back = document.createElement('a');
    back.href = '#/';
    back.textContent = 'Вернуться на склад';
    section.append(heading, message, back);
    app.replaceChildren(section);
    document.title = 'Ошибка загрузки — Склад';
  } finally {
    if (version === navigationVersion) {
      app.setAttribute('aria-busy', 'false');
      hidePreloader();
    }
  }
}

window.addEventListener('hashchange', loadPage);
loadPage();

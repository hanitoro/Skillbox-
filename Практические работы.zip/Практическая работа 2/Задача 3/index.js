'use strict';

const prices = [100, 500, 250, 750, 300];

const priceList = document.querySelector('.price-list');
const ascendingButton = document.querySelector('.sort-ascending');
const descendingButton = document.querySelector('.sort-descending');

function renderPrices() {
  priceList.innerHTML = '';

  prices.forEach((price) => {
    const item = document.createElement('li');
    item.textContent = price;
    priceList.append(item);
  });
}

function sortAscending() {
  prices.sort();

  renderPrices();
}

function sortDescending() {
  prices.sort((firstPrice, secondPrice) => secondPrice - firstPrice);

  renderPrices();
}

ascendingButton.addEventListener('click', sortAscending);
descendingButton.addEventListener('click', sortDescending);

renderPrices();

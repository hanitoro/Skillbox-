'use strict';

const thumbnails = document.querySelector('.thumbnails');
const fullImageContainer = document.querySelector('.full-image');

thumbnails.addEventListener('click', (event) => {
  const thumbnail = event.target.closest('.thumbnail');
  if (!thumbnail || !thumbnails.contains(thumbnail)) {
    return;
  }

  const smallImage = thumbnail.querySelector('img');
  const fullImage = document.createElement('img');
  fullImage.src = smallImage.getAttribute('src');
  fullImage.alt = smallImage.alt;
  fullImageContainer.replaceChildren(fullImage);

  const previousThumbnail = thumbnails.querySelector('.thumbnail.selected');
  if (previousThumbnail) {
    previousThumbnail.classList.remove('selected');
    previousThumbnail.setAttribute('aria-pressed', 'false');
  }

  thumbnail.classList.add('selected');
  thumbnail.setAttribute('aria-pressed', 'true');
});

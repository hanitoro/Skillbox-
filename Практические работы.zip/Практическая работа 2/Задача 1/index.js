'use strict';

const thumbnails = document.querySelectorAll('.thumbnail');
const fullImageContainer = document.querySelector('.full-image');

thumbnails.forEach((thumbnail) => {
  thumbnail.addEventListener('click', () => {
    const smallImage = thumbnail.querySelector('img');
    const fullImage = document.createElement('img');

    // Используем URL выбранной миниатюры для большого изображения.
    fullImage.src = smallImage.getAttribute('src');
    fullImage.alt = smallImage.alt;
    fullImageContainer.replaceChildren(fullImage);

    thumbnails.forEach((item) => {
      item.classList.remove('selected');
      item.setAttribute('aria-pressed', 'false');
    });

    thumbnail.classList.add('selected');
    thumbnail.setAttribute('aria-pressed', 'true');
  });
});

'use strict';

function globalError() {
  const error = new Error('Глобальная ошибка');
  error.name = 'GlobalError';
  throw error;
}

function localError() {
  const error = new Error('Локальная ошибка');
  error.name = 'LocalError';
  throw error;
}

function testErrorScope(fn) {
  try {
    try {
      fn();
    } catch (error) {
      // Остальные ошибки передаём во внешний catch.
      if (error.name !== 'LocalError') {
        throw error;
      }

      console.log('Обнаружена локальная ошибка');
      console.error(error);
    }
  } catch (error) {
    console.log('Обнаружена глобальная ошибка');
    console.error(error);
  }
}

testErrorScope(localError);
testErrorScope(globalError);

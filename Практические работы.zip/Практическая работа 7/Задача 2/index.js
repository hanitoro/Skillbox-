'use strict';

function greeting() {
  const username = prompt('Введите имя пользователя');

  if (username === null || username.trim() === '') {
    throw new Error('Имя обязательно для заполнения');
  }

  return username.trim();
}

function requestGreeting() {
  const result = document.querySelector('.greeting-result');

  try {
    const username = greeting();
    result.textContent = 'Здравствуйте, ' + username + '!';
  } catch (error) {
    result.textContent = '';
    alert(error.message);
  }
}

document.querySelector('.ask-name').addEventListener('click', requestGreeting);
requestGreeting();

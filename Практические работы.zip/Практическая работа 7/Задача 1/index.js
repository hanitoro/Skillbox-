'use strict';

function hello() {
  console.log('Skill');
}

try {
  // Опечатка из условия оставлена, чтобы продемонстрировать обработку ошибки.
  helo();
} catch (error) {
  console.error('Ошибка при вызове функции:', error);
}

console.log('complete');

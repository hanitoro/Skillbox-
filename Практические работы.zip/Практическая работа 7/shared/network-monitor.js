'use strict';

function createNetworkMonitor({
  url = 'https://sb-film.skillbox.cc/ping',
  intervalMs = 5000,
  slowMs = 500,
  timeoutMs = null
} = {}) {
  const notification = document.createElement('div');
  notification.className = 'network-notice';
  notification.setAttribute('role', 'status');
  notification.setAttribute('aria-live', 'polite');
  notification.hidden = true;
  document.body.append(notification);

  let running = false;
  let intervalId = null;
  let activeRequest = null;
  let status = 'ok';

  function showStatus(nextStatus) {
    status = nextStatus;
    notification.dataset.state = nextStatus;
    notification.textContent = nextStatus === 'error'
      ? 'Неполадки с сетью'
      : nextStatus === 'slow' ? 'Медленное соединение' : '';
    notification.hidden = nextStatus === 'ok';
  }

  function clearRequestTimers(request) {
    clearTimeout(request.slowTimer);
    clearTimeout(request.timeoutTimer);
  }

  async function checkConnection() {
    if (!running) return;

    // Проверка следующего интервала заменяет зависший старый запрос.
    if (activeRequest) {
      clearRequestTimers(activeRequest);
      activeRequest.controller.abort();
    }

    const request = {
      controller: new AbortController(),
      slowTimer: null,
      timeoutTimer: null,
      timedOut: false
    };
    activeRequest = request;
    const startedAt = performance.now();

    request.slowTimer = setTimeout(() => {
      // Ошибку сети скрываем только после успешного ответа, а не при новой попытке.
      if (running && activeRequest === request && status !== 'error') {
        showStatus('slow');
      }
    }, slowMs);

    if (timeoutMs !== null) {
      request.timeoutTimer = setTimeout(() => {
        if (running && activeRequest === request) {
          request.timedOut = true;
          showStatus('error');
          request.controller.abort();
        }
      }, timeoutMs);
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        cache: 'no-store',
        signal: request.controller.signal
      });

      if (!response.ok) {
        throw new Error('Ошибка проверки соединения: ' + response.status);
      }

      if (!running || activeRequest !== request) return;
      const elapsed = performance.now() - startedAt;

      if (request.timedOut || (timeoutMs !== null && elapsed >= timeoutMs)) {
        showStatus('error');
      } else {
        showStatus(elapsed > slowMs ? 'slow' : 'ok');
      }
    } catch (error) {
      if (running && activeRequest === request) {
        showStatus('error');
      }
    } finally {
      clearRequestTimers(request);
      if (activeRequest === request) activeRequest = null;
    }
  }

  function start() {
    if (running) return;
    running = true;
    checkConnection();
    intervalId = setInterval(checkConnection, intervalMs);
  }

  function stop() {
    running = false;
    clearInterval(intervalId);
    intervalId = null;

    if (activeRequest) {
      clearRequestTimers(activeRequest);
      activeRequest.controller.abort();
      activeRequest = null;
    }

    showStatus('ok');
  }

  return { start, stop };
}

'use strict';

// Приложение «Фильмотека» из архива практической работы.
let user;

function setUser(userData) {
  user = userData;
}

function getUser() {
  return user;
}

function handleErrorResponse(data, status) {
  const errors = data && Array.isArray(data.errors) ? data.errors : [];
  const isNeedAuth = errors.some(error => error.location === 'headers' && error.param === 'email');

  if (isNeedAuth) {
    const error = new Error('Некорректный email');
    error.name = 'AuthError';
    throw error;
  }

  throw new Error('Не удалось загрузить фильмы. Код ответа: ' + status + '.');
}

async function getFilms() {
  const currentUser = getUser();
  const response = await fetch('https://sb-film.skillbox.cc/films', {
    headers: { email: currentUser.email }
  });
  const data = await response.json();

  if (!response.ok) handleErrorResponse(data, response.status);
  if (!Array.isArray(data)) throw new Error('Сервер вернул некорректный список фильмов.');
  return data;
}

function renderTopBar(currentUser) {
  const element = document.createElement('div');
  element.className = 'topbar';

  const logo = document.createElement('span');
  logo.className = 'topbar-logo';
  logo.textContent = 'Фильмотека';

  const userInfo = document.createElement('div');
  userInfo.className = 'topbar-user user';
  const name = document.createElement('div');
  name.className = 'user-name';
  name.textContent = currentUser.name;
  const email = document.createElement('div');
  email.className = 'user-email';
  email.textContent = currentUser.email;
  userInfo.append(name, email);
  element.append(logo, userInfo);
  return element;
}

function renderFilms(films) {
  const element = document.createElement('div');
  element.className = 'films';

  if (films.length === 0) {
    element.textContent = 'Список фильмов пока пуст';
    return element;
  }

  films.forEach((film) => {
    const filmElement = document.createElement('div');
    filmElement.className = 'films-card';
    filmElement.dataset.watched = film.isWatched;
    filmElement.textContent = film.title + ' (' + film.releaseYear + ')';
    element.append(filmElement);
  });

  return element;
}

function renderGlobalError(message) {
  const element = document.createElement('div');
  element.className = 'error';
  const heading = document.createElement('div');
  heading.className = 'error-title';
  heading.textContent = 'Упс… Возникла ошибка';
  const description = document.createElement('div');
  description.className = 'error-message';
  description.textContent = message;
  const retry = document.createElement('button');
  retry.type = 'button';
  retry.textContent = 'Повторить';
  retry.addEventListener('click', initApp);
  element.append(heading, description, retry);
  return element;
}

function renderAuthForm(props) {
  const form = document.createElement('form');
  form.className = 'authForm';
  form.innerHTML = `
    <label class="field-label">
      <span class="field-caption">Ваше имя</span>
      <input class="name" type="text" name="name" required placeholder="Василий" autocomplete="name">
    </label>
    <label class="field-label">
      <span class="field-caption">Эл. почта</span>
      <input class="email" type="email" name="email" required placeholder="example@mail.com" autocomplete="email">
    </label>
    <p class="authForm-error" role="alert"></p>
    <button class="authForm-submit" type="submit">Войти</button>
  `;

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const name = String(formData.get('name') || '').trim();
    const email = String(formData.get('email') || '').trim();
    const error = form.querySelector('.authForm-error');

    if (!name || !email) {
      error.textContent = 'Введите имя и электронную почту.';
      return;
    }

    error.textContent = '';
    await props.onSubmit({ name, email });
  });

  return form;
}

function initAuth(message = '') {
  const app = document.querySelector('.app');
  const form = renderAuthForm({
    onSubmit: async (userData) => {
      setUser(userData);
      await initApp();
    }
  });
  form.querySelector('.authForm-error').textContent = message;
  app.replaceChildren(form);
}

async function initApp() {
  const app = document.querySelector('.app');
  const currentUser = getUser();

  if (!currentUser) {
    initAuth();
    return;
  }

  const loading = document.createElement('p');
  loading.textContent = 'Загрузка фильмов…';
  app.replaceChildren(renderTopBar(currentUser), loading);

  try {
    const films = await getFilms();
    app.replaceChildren(renderTopBar(currentUser), renderFilms(films));
  } catch (error) {
    if (error.name === 'AuthError') {
      setUser(null);
      initAuth(error.message);
      return;
    }

    const message = error instanceof TypeError
      ? 'Не удалось связаться с сервером. Проверьте подключение к интернету.'
      : error.message;
    app.replaceChildren(renderTopBar(currentUser), renderGlobalError(message));
  }
}

initApp();

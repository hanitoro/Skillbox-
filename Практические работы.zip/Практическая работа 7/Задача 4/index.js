'use strict';

const connectionMonitor = createNetworkMonitor({
  intervalMs: 5000,
  slowMs: 500
});

connectionMonitor.start();
window.addEventListener('pagehide', () => { connectionMonitor.stop(); });
window.addEventListener('pageshow', (event) => {
  if (event.persisted) connectionMonitor.start();
});

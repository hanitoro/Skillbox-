import { progress } from '../shared/progress.js';

function startProgress() {
  progress(3, 'progress-bar', 'timer');
}

document.querySelector('.restart').addEventListener('click', startProgress);
startProgress();

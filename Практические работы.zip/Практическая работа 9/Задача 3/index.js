import { getCatImages, getDogImages } from '../shared/mock-requests.js';
import { progress } from '../shared/progress.js';
import { createImageRow, showError } from '../shared/gallery.js';

let catsAnimation;
let dogsAnimation;

getCatImages((time) => {
  catsAnimation = progress(time, 'cats-progress', 'cats-timer');
}).then((urls) => {
  // Дожидаемся последнего кадра, чтобы изображения появились после заполнения полосы.
  return catsAnimation.then(() => {
    document.querySelector('.cats-gallery').append(createImageRow(urls, 'Коты'));
    document.querySelector('.dogs-stage').hidden = false;

    // Второй запрос начинается только после завершения первого и показа котов.
    return getDogImages((time) => {
      dogsAnimation = progress(time, 'dogs-progress', 'dogs-timer');
    });
  });
}).then((urls) => {
  return dogsAnimation.then(() => {
    document.querySelector('.dogs-gallery').append(createImageRow(urls, 'Собаки'));
  });
}).catch(showError);

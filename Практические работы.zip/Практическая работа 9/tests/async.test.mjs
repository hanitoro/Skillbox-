import test from 'node:test';
import assert from 'node:assert/strict';
import { progress } from '../shared/progress.js';
import { getCatImages } from '../shared/mock-requests.js';

class Element {
  constructor() {
    this.children = [];
    this.style = {};
    this.attributes = {};
    this.textContent = '';
    this.hidden = false;
  }
  append(child) { this.children.push(child); }
  setAttribute(name, value) { this.attributes[name] = value; }
}

async function flush() {
  for (let index = 0; index < 12; index++) await Promise.resolve();
}

function createEnvironment(t, ids) {
  let now = 0;
  let nextId = 0;
  const timers = new Map();
  const elements = Object.fromEntries(ids.map(id => [id, new Element()]));
  const replacements = {
    document: { querySelector: selector => elements[selector.slice(1)] || null, createElement: () => new Element() },
    performance: { now: () => now },
    setTimeout(callback, delay) {
      const id = ++nextId;
      timers.set(id, { callback, at: now + delay });
      return id;
    },
    clearTimeout: id => timers.delete(id),
    requestAnimationFrame(callback) {
      const id = ++nextId;
      timers.set(id, { callback: () => callback(now), at: now + 16 });
      return id;
    },
    cancelAnimationFrame: id => timers.delete(id)
  };
  for (const [key, value] of Object.entries(replacements)) {
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, key);
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
    t.after(() => {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete globalThis[key];
    });
  }
  const originalRandom = Math.random;
  t.after(() => { Math.random = originalRandom; });

  async function advance(milliseconds) {
    const target = now + milliseconds;
    await flush();
    while (true) {
      const next = [...timers].filter(([, timer]) => timer.at <= target)
        .sort((first, second) => first[1].at - second[1].at || first[0] - second[0])[0];
      if (!next) break;
      const [id, timer] = next;
      timers.delete(id);
      now = timer.at;
      timer.callback();
      await flush();
    }
    now = target;
    await flush();
  }
  return { elements, advance, timers };
}

test('Мок-запросы возвращают массивы через 2, 3, 4 и 5 секунд', async (t) => {
  const clock = createEnvironment(t, []);
  for (const [random, expected] of [[0, 2], [0.25, 3], [0.5, 4], [0.9999, 5]]) {
    Math.random = () => random;
    let result;
    let seconds;
    const request = getCatImages(time => { seconds = time; });
    request.then(urls => { result = urls; });
    assert.equal(seconds, expected);
    await clock.advance(expected * 1000 - 1);
    assert.equal(result, undefined);
    await clock.advance(1);
    assert.equal(result.length, 3);
    assert.ok(result.every(url => url.endsWith('.jpg')));
  }
});

test('Параллельные запросы показывают ряды по готовности, а не в фиксированном порядке', async (t) => {
  const clock = createEnvironment(t, ['gallery', 'loading-status', 'error-message']);
  const values = [0.99, 0];
  Math.random = () => values.shift();
  await import('../Задача 1/index.js?dogs-first');
  assert.equal(clock.elements.gallery.children.length, 0);
  await clock.advance(1999);
  assert.equal(clock.elements.gallery.children.length, 0);
  await clock.advance(1);
  assert.equal(clock.elements.gallery.children[0].attributes['aria-label'], 'Собаки');
  await clock.advance(3000);
  assert.equal(clock.elements.gallery.children[1].attributes['aria-label'], 'Коты');
  assert.equal(clock.elements['loading-status'].textContent, '');
});

test('В другом запуске первым может завершиться запрос котов', async (t) => {
  const clock = createEnvironment(t, ['gallery', 'loading-status', 'error-message']);
  const values = [0, 0.99];
  Math.random = () => values.shift();
  await import('../Задача 1/index.js?cats-first');
  await clock.advance(5000);
  assert.deepEqual(clock.elements.gallery.children.map(row => row.attributes['aria-label']), ['Коты', 'Собаки']);
});

test('Progress bar плавно растёт, работает минимум 2 секунды и полностью останавливает таймер', async (t) => {
  const clock = createEnvironment(t, ['bar', 'timer']);
  const done = progress(1, 'bar', 'timer');
  assert.equal(clock.elements.bar.style.transform, 'scaleX(0)');
  await clock.advance(1024);
  const fraction = +clock.elements.bar.style.transform.slice(7, -1);
  assert.ok(fraction > 0.5 && fraction < 0.6);
  assert.equal(clock.elements.timer.textContent, '1 с');
  await clock.advance(976);
  assert.deepEqual(await done, { cancelled: false, time: 2 });
  assert.equal(clock.elements.bar.style.transform, 'scaleX(1)');
  assert.equal(clock.elements.timer.textContent, '2 с');
  assert.equal(clock.timers.size, 0);
  await clock.advance(10000);
  assert.equal(clock.elements.timer.textContent, '2 с');
  for (const duration of [0, -1, NaN, Infinity]) assert.throws(() => progress(duration, 'bar', 'timer'), RangeError);
});

test('У двух полос независимые таймеры; повторный запуск отменяет только старую анимацию своей полосы', async (t) => {
  const clock = createEnvironment(t, ['first', 'first-timer', 'second', 'second-timer']);
  const oldFirst = progress(5, 'first', 'first-timer');
  const second = progress(5, 'second', 'second-timer');
  await clock.advance(1000);
  const newFirst = progress(2, 'first', 'first-timer');
  assert.deepEqual(await oldFirst, { cancelled: true });
  await clock.advance(2000);
  await newFirst;
  assert.equal(clock.elements['first-timer'].textContent, '2 с');
  assert.notEqual(clock.elements.second.style.transform, 'scaleX(1)');
  await clock.advance(2016);
  await second;
  assert.equal(clock.elements['second-timer'].textContent, '5 с');
  assert.equal(clock.elements['first-timer'].textContent, '2 с');
  assert.equal(clock.timers.size, 0);
});

test('В объединённой задаче второй запрос начинается после первого; оба ряда ждут свою полосу', async (t) => {
  const ids = ['cats-gallery', 'dogs-gallery', 'cats-progress', 'dogs-progress', 'cats-timer', 'dogs-timer', 'dogs-stage', 'error-message'];
  const clock = createEnvironment(t, ids);
  clock.elements['dogs-stage'].hidden = true;
  const values = [0, 0.99];
  let requests = 0;
  Math.random = () => { requests++; return values.shift(); };
  await import('../Задача 3/index.js?sequential');
  assert.equal(requests, 1);
  await clock.advance(1999);
  assert.equal(clock.elements['cats-gallery'].children.length, 0);
  assert.equal(requests, 1);
  await clock.advance(1);
  assert.equal(clock.elements['cats-gallery'].children.length, 1);
  assert.equal(clock.elements['cats-progress'].style.transform, 'scaleX(1)');
  assert.equal(clock.elements['dogs-gallery'].children.length, 0);
  assert.equal(clock.elements['dogs-stage'].hidden, false);
  assert.equal(requests, 2);
  await clock.advance(4999);
  assert.equal(clock.elements['dogs-gallery'].children.length, 0);
  await clock.advance(16);
  assert.equal(clock.elements['dogs-gallery'].children.length, 1);
  assert.equal(clock.elements['dogs-progress'].style.transform, 'scaleX(1)');
  assert.equal(clock.elements['cats-timer'].textContent, '2 с');
  assert.equal(clock.elements['dogs-timer'].textContent, '5 с');
  assert.equal(clock.timers.size, 0);
});

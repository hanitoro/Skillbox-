'use strict';

const books = [
  'Мастер и Маргарита',
  'Гарри Поттер',
  'Над пропастью во ржи',
  'Властелин колец',
  'Дюна',
  'Отцы и дети'
];

const bookList = document.querySelector('.book-list');
const addBookButton = document.querySelector('.add-book');
const searchBookButton = document.querySelector('.search-book');

const appendBook = (book) => {
  const item = document.createElement('li');
  item.textContent = book;
  bookList.appendChild(item);
};

addBookButton.addEventListener('click', () => {
  const input = prompt('Введите название книги:');

  if (input === null || input.trim() === '') {
    alert('Название книги не введено!');
    return;
  }

  const book = input.trim();
  books.push(book);
  bookList.querySelector('.found')?.classList.remove('found');
  appendBook(book);
});

searchBookButton.addEventListener('click', () => {
  const input = prompt('Введите название книги для поиска:');

  if (input === null) {
    return;
  }

  const searchTitle = input.trim().toLocaleLowerCase('ru');
  const bookItems = bookList.querySelectorAll('li');
  const foundIndex = books.findIndex(book => book.toLocaleLowerCase('ru') === searchTitle);

  bookList.querySelector('.found')?.classList.remove('found');

  if (foundIndex === -1) {
    alert('Книга не найдена!');
    return;
  }

  bookItems[foundIndex].classList.add('found');
});

books.forEach(appendBook);

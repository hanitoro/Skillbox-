'use strict';

const promocodeObj = {
  promocode: 'PROM50',
  gift: 'Скидка 50%'
};

const cookieName = 'theme4_task2_promocode';
const promoForm = document.querySelector('.promo-form');
const promoInput = document.querySelector('.promocode');
const promoMessage = document.querySelector('.promo-message');

function getCookie(name) {
  const prefix = name + '=';
  const cookie = document.cookie.split(';').map(item => item.trim()).find(item => item.startsWith(prefix));

  if (!cookie) {
    return '';
  }

  try {
    return decodeURIComponent(cookie.slice(prefix.length));
  } catch {
    return '';
  }
}

function resetPromoState() {
  promoForm.classList.remove('is-applied');
  promoMessage.textContent = '';
  promoMessage.hidden = true;
}

function showAppliedPromo() {
  promoInput.value = promocodeObj.promocode;
  promoForm.classList.add('is-applied');
  promoMessage.textContent = 'Промокод применён. ' + promocodeObj.gift;
  promoMessage.hidden = false;
}

promoInput.addEventListener('input', resetPromoState);

promoForm.addEventListener('submit', (event) => {
  event.preventDefault();

  if (promoInput.value.trim() === promocodeObj.promocode) {
    showAppliedPromo();
    document.cookie = cookieName + '=' + encodeURIComponent(promocodeObj.promocode)
      + '; max-age=2592000; path=/; SameSite=Lax';
  } else {
    resetPromoState();
    document.cookie = cookieName + '=; max-age=0; path=/; SameSite=Lax';
  }
});

if (getCookie(cookieName) === promocodeObj.promocode) {
  showAppliedPromo();
}

'use strict';

const promocodeArr = [
  { promocode: 'PROM10', gift: 'Скидка 10%' },
  { promocode: 'PROM50', gift: 'Скидка 50%' },
  { promocode: 'GIFT', gift: 'Подарок в корзине' }
];

const cookieName = 'theme4_task3_promocode';
const promoForm = document.querySelector('.promo-form');
const promoInput = document.querySelector('.promocode');
const promoMessage = document.querySelector('.promo-message');

function getCookie(name) {
  const prefix = name + '=';
  const cookie = document.cookie.split(';').map(item => item.trim()).find(item => item.startsWith(prefix));

  if (!cookie) {
    return '';
  }

  try {
    return decodeURIComponent(cookie.slice(prefix.length));
  } catch {
    return '';
  }
}

function findPromocode(value) {
  return promocodeArr.find(item => item.promocode === value);
}

function resetPromoState() {
  promoForm.classList.remove('is-applied');
  promoMessage.textContent = '';
  promoMessage.hidden = true;
}

function showAppliedPromo(promo) {
  promoInput.value = promo.promocode;
  promoForm.classList.add('is-applied');
  promoMessage.textContent = 'Промокод применён. ' + promo.gift;
  promoMessage.hidden = false;
}

promoInput.addEventListener('input', resetPromoState);

promoForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const promo = findPromocode(promoInput.value.trim());

  if (promo) {
    showAppliedPromo(promo);
    document.cookie = cookieName + '=' + encodeURIComponent(promo.promocode)
      + '; max-age=2592000; path=/; SameSite=Lax';
  } else {
    resetPromoState();
    document.cookie = cookieName + '=; max-age=0; path=/; SameSite=Lax';
  }
});

const savedPromo = findPromocode(getCookie(cookieName));

if (savedPromo) {
  showAppliedPromo(savedPromo);
}

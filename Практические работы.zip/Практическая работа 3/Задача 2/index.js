'use strict';

const deliveryForm = document.querySelector('.delivery-form');
const productNameInput = document.querySelector('.product-name');
const weightInput = document.querySelector('.weight');
const distanceInput = document.querySelector('.distance');
const deliveryError = document.querySelector('.delivery-error');
const productList = document.querySelector('.product-list');

function appendProduct(product) {
  const row = document.createElement('tr');
  const values = [
    product.name,
    product.weight,
    product.distance,
    product.deliveryCost.toFixed(2) + ' руб.'
  ];

  values.forEach((value) => {
    const cell = document.createElement('td');
    cell.textContent = value;
    row.append(cell);
  });

  productList.appendChild(row);
}

deliveryForm.addEventListener('submit', (event) => {
  event.preventDefault();
  deliveryError.textContent = '';

  // Пустые обязательные поля показывают стандартную подсказку браузера.
  if (!deliveryForm.reportValidity()) {
    return;
  }

  const name = productNameInput.value.trim();
  const weight = +weightInput.value;
  const distance = +distanceInput.value;

  if (name === '') {
    deliveryError.textContent = 'Введите название товара.';
    return;
  }

  if (!Number.isFinite(weight) || weight <= 0 || !Number.isFinite(distance) || distance <= 0) {
    deliveryError.textContent = 'Пожалуйста, введите корректные значения для веса и расстояния.';
    return;
  }

  const deliveryCost = (weight * distance) / 10;

  if (!Number.isFinite(deliveryCost)) {
    deliveryError.textContent = 'Слишком большие значения для расчёта стоимости доставки.';
    return;
  }

  appendProduct({ name, weight, distance, deliveryCost });
  deliveryForm.reset();
});

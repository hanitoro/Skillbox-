'use strict';

const cardTextInput = document.querySelector('.card-text');
const cardColorSelect = document.querySelector('.card-color');
const card = document.querySelector('.card');

cardTextInput.addEventListener('input', () => {
  card.textContent = cardTextInput.value;
});

cardTextInput.addEventListener('focus', () => {
  cardTextInput.classList.add('focused');
});

cardTextInput.addEventListener('blur', () => {
  cardTextInput.classList.remove('focused');
});

cardColorSelect.addEventListener('change', () => {
  card.style.backgroundColor = cardColorSelect.value;
});

card.style.backgroundColor = cardColorSelect.value;

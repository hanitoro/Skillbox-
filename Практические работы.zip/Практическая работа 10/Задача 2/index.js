import { createEditableDeliveries } from '../shared/createDeliveries.js';

const deliveryArr = createEditableDeliveries();
const list = document.querySelector('.delivery-list');
deliveryArr.forEach((delivery) => { list.append(delivery.element); });

@echo off
python "%~dp0server.py"
if errorlevel 1 pause

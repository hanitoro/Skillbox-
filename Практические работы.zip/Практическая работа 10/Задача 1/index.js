import { Delivery } from '../shared/Delivery.js';

const deliveryArr = [
  new Delivery('Ольга', 'ул. Вымыслов, д. 12', 8),
  new Delivery('Дмитрий', 'ул. Задачная, д. 7', 3),
  new Delivery('Оля', 'ул. Ткачей, д. 43', 11)
];

const list = document.querySelector('.delivery-list');
deliveryArr.forEach((delivery) => { list.append(delivery.element); });

import { EditDelivery } from '../shared/EditDelivery.js';
import { createEditableDeliveries } from '../shared/createDeliveries.js';
import { formatDistance } from '../shared/validation.js';

const deliveryArr = createEditableDeliveries();
const list = document.querySelector('.delivery-list');
const result = document.querySelector('.total-distance');
deliveryArr.forEach((delivery) => { list.append(delivery.element); });

function showTotalDistance() {
  const totalDistance = EditDelivery.getTotalDistance(deliveryArr);
  result.textContent = 'Общее расстояние: ' + formatDistance(totalDistance) + ' км';
  result.hidden = false;
}

document.querySelector('.calculate-total').addEventListener('click', showTotalDistance);
list.addEventListener('deliverychange', () => {
  if (!result.hidden) showTotalDistance();
});

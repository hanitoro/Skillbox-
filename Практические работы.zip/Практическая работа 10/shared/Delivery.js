import { validateText, validateDistance, formatDistance } from './validation.js';

export class Delivery {
  constructor(name, address, distance) {
    this._element = null;
    this._valueElements = {};
    this.name = name;
    this.address = address;
    this.distance = distance;
  }

  get name() { return this._name; }
  set name(value) {
    this._name = validateText(value, 'Имя');
    this._updateView();
  }

  get address() { return this._address; }
  set address(value) {
    this._address = validateText(value, 'Адрес');
    this._updateView();
  }

  get distance() { return this._distance; }
  set distance(value) {
    this._distance = validateDistance(value);
    this._updateView();
  }

  get element() { return this.createElement(); }

  createField(key, label) {
    const field = document.createElement('div');
    field.className = 'delivery-field';
    const caption = document.createElement('span');
    caption.className = 'delivery-label';
    caption.textContent = label;
    const value = document.createElement('strong');
    this._valueElements[key] = value;
    field.append(caption, value);
    return field;
  }

  createElement() {
    if (this._element) return this._element;
    this._element = document.createElement('article');
    this._element.className = 'delivery-card';
    this._element.append(
      this.createField('name', 'Имя'),
      this.createField('address', 'Адрес'),
      this.createField('distance', 'Расстояние')
    );
    this._updateView();
    return this._element;
  }

  _updateView() {
    if (!this._element) return;
    this._valueElements.name.textContent = this.name;
    this._valueElements.address.textContent = this.address;
    this._valueElements.distance.textContent = formatDistance(this.distance) + ' км';
    this._element.setAttribute('aria-label', 'Доставка для ' + this.name);
    this._notifyChange();
  }

  _notifyChange() {
    if (this._element) {
      this._element.dispatchEvent(new CustomEvent('deliverychange', { bubbles: true }));
    }
  }
}

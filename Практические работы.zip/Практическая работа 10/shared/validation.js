export function validateText(value, label) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw new TypeError(label + ': заполните поле.');
  }
  return value.trim();
}

export function validateDistance(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new TypeError('Расстояние должно быть неотрицательным числом.');
  }
  return value;
}

export function parseDistance(value) {
  const text = String(value).trim();
  if (text === '') throw new TypeError('Укажите расстояние.');
  return validateDistance(+text.replace(',', '.'));
}

export const statusLabels = {
  delivery: 'Доставляется',
  delivered: 'Доставлен',
  canceled: 'Отменён'
};

export function validateStatus(value) {
  if (!Object.hasOwn(statusLabels, value)) throw new TypeError('Выберите корректный статус доставки.');
  return value;
}

export function formatDistance(value) {
  return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 10 }).format(value);
}

'use strict';

const storageKey = 'theme5_films';
const filmForm = document.querySelector('.film-form');
const titleInput = document.querySelector('.film-title');
const genreInput = document.querySelector('.film-genre');
const yearInput = document.querySelector('.film-year');
const watchedInput = document.querySelector('.film-watched');
const submitButton = document.querySelector('.submit-film');
const cancelButton = document.querySelector('.cancel-edit');
const sortSelect = document.querySelector('.sort-by');
const sortButton = document.querySelector('.sort-films');
const filmList = document.querySelector('.film-list');
const formError = document.querySelector('.form-error');
const storageMessage = document.querySelector('.storage-message');

function saveFilms(updatedFilms) {
  try {
    localStorage.setItem(storageKey, JSON.stringify(updatedFilms));
    storageMessage.textContent = '';
    return true;
  } catch {
    storageMessage.textContent = 'Не удалось сохранить список. Разрешите хранение данных в браузере и повторите действие.';
    return false;
  }
}

function loadFilms() {
  try {
    const savedFilms = localStorage.getItem(storageKey);

    if (savedFilms === null) {
      const initialFilms = [
        { id: 1, title: 'Назад в будущее', genre: 'Приключение', year: 1985, watched: true },
        { id: 2, title: 'Матрица', genre: 'Киберпанк', year: 1999, watched: false }
      ];
      saveFilms(initialFilms);
      return initialFilms;
    }

    const savedData = JSON.parse(savedFilms);

    if (!Array.isArray(savedData)) {
      throw new Error('Сохранённые данные должны быть массивом.');
    }

    const validFilms = savedData.every((film) => {
      return film !== null
        && Number.isSafeInteger(film.id) && film.id > 0
        && typeof film.title === 'string' && film.title.trim() !== ''
        && typeof film.genre === 'string' && film.genre.trim() !== ''
        && Number.isInteger(film.year) && film.year >= 1 && film.year <= 9999
        && typeof film.watched === 'boolean';
    });
    const uniqueIds = new Set(savedData.map(film => film && film.id));

    if (!validFilms || uniqueIds.size !== savedData.length) {
      throw new Error('Неверный формат данных о фильмах.');
    }

    return savedData;
  } catch {
    storageMessage.textContent = 'Не удалось загрузить сохранённый список фильмов. Проверьте доступ к хранилищу браузера.';
    return [];
  }
}

let films = loadFilms();
let editingFilmId = null;

function resetForm() {
  filmForm.reset();
  editingFilmId = null;
  submitButton.textContent = 'Добавить';
  cancelButton.hidden = true;
  formError.textContent = '';
}

function startEditing(id) {
  const film = films.find(item => item.id === id);

  if (!film) {
    return;
  }

  editingFilmId = film.id;
  titleInput.value = film.title;
  genreInput.value = film.genre;
  yearInput.value = film.year;
  watchedInput.checked = film.watched;
  submitButton.textContent = 'Обновить';
  cancelButton.hidden = false;
  formError.textContent = '';
  titleInput.focus();
}

function deleteFilm(id) {
  const updatedFilms = films.filter(film => film.id !== id);

  if (!saveFilms(updatedFilms)) {
    return;
  }

  films = updatedFilms;

  if (editingFilmId === id) {
    resetForm();
  }

  renderFilms();
}

function renderFilms() {
  filmList.innerHTML = '';
  films.forEach(appendFilm);
}

function appendFilm(film) {
  const row = document.createElement('tr');

  [film.title, film.genre, film.year, film.watched ? 'Да' : 'Нет'].forEach((value) => {
    const cell = document.createElement('td');
    cell.textContent = value;
    row.append(cell);
  });

  const actions = document.createElement('td');
  const buttons = document.createElement('div');
  buttons.className = 'row-actions';

  const editButton = document.createElement('button');
  editButton.type = 'button';
  editButton.textContent = 'Редактировать';
  editButton.addEventListener('click', () => {
    startEditing(film.id);
  });

  const deleteButton = document.createElement('button');
  deleteButton.type = 'button';
  deleteButton.textContent = 'Удалить';
  deleteButton.addEventListener('click', () => {
    deleteFilm(film.id);
  });

  buttons.append(editButton, deleteButton);
  actions.append(buttons);
  row.append(actions);
  filmList.appendChild(row);
}

filmForm.addEventListener('submit', (event) => {
  event.preventDefault();
  formError.textContent = '';

  const title = titleInput.value.trim();
  const genre = genreInput.value.trim();
  const year = +yearInput.value;

  if (title === '' || genre === '' || yearInput.value.trim() === '') {
    formError.textContent = 'Заполните название, жанр и год выпуска фильма.';
    return;
  }

  if (!Number.isInteger(year) || year < 1 || year > 9999) {
    formError.textContent = 'Введите корректный год выпуска: целое число от 1 до 9999.';
    return;
  }

  const isNewFilm = editingFilmId === null;
  const id = isNewFilm
    ? films.reduce((maximum, film) => Math.max(maximum, film.id), 0) + 1
    : editingFilmId;
  const filmData = { id, title, genre, year, watched: watchedInput.checked };
  const updatedFilms = isNewFilm
    ? films.concat(filmData)
    : films.map(film => film.id === editingFilmId ? filmData : film);

  if (!saveFilms(updatedFilms)) {
    return;
  }

  films = updatedFilms;
  resetForm();
  if (isNewFilm) {
    appendFilm(filmData);
  } else {
    renderFilms();
  }
});

cancelButton.addEventListener('click', resetForm);

sortButton.addEventListener('click', () => {
  const criterion = sortSelect.value;
  const sortedFilms = films.slice().sort((firstFilm, secondFilm) => {
    if (criterion === 'year') {
      return firstFilm.year - secondFilm.year;
    }

    return firstFilm[criterion].localeCompare(secondFilm[criterion], 'ru', { sensitivity: 'base' });
  });

  if (saveFilms(sortedFilms)) {
    films = sortedFilms;
    renderFilms();
  }
});

renderFilms();
